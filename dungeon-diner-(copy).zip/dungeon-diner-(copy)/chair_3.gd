extends AnimatedSprite2D

func _process (_delta):
	if Global_Var.one_customer == true and Global_Var.at_table_3 == true:
		if Global_Var.dropped == false:
			frame = 1
			Global_Var.dropped = true
