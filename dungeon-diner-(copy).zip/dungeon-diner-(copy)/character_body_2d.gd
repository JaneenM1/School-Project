extends CharacterBody2D

var is_grabbed : bool = false

func _ready():
	input_pickable = true

func _process(_delta):
	if is_grabbed:
		var mouse_pos = get_global_mouse_position()
		global_position = lerp(global_position, mouse_pos, 0.2)

func _input(event):
	if event is InputEventMouseButton and event.button_index and event.button_index == MOUSE_BUTTON_LEFT:
		if not event.pressed:
			if Global_Var.can_drop == true:
				is_grabbed = false
				Global_Var.one_customer = true
				queue_free()

func _input_event(_viewport, event, _shape_idx):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			is_grabbed = true
