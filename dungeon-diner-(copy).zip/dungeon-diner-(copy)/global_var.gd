extends Node

var can_drop : bool = false
var one_customer : bool = false
var at_table_1 : bool = false
var at_table_2 : bool = false
var at_table_3 : bool = false
var dropped : bool = false
