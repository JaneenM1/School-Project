extends Area2D

func _on_mouse_entered() -> void:
	Global_Var.can_drop = true
	Global_Var.at_table_3 = true

func _on_mouse_exited() -> void:
	Global_Var.can_drop = false
